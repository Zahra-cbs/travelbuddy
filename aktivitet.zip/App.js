import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {initializeApp} from 'firebase/app';
import 'firebase/firestore';
import HomeScreen from './HomeScreen';
import DetailScreen from './DetailScreen';
import CreateScreen from './CreateScreen';
import { getFirestore } from 'firebase/firestore';

//connecter til min database
const firebaseConfig = {
  apiKey: "AIzaSyABbzO-5Rj9B90GeiMURRzZTU_Xn0vd0SE",
  authDomain: "aktiviteter-eefa7.firebaseapp.com",
  projectId: "aktiviteter-eefa7",
  storageBucket: "aktiviteter-eefa7.appspot.com",
  messagingSenderId: "636213952365",
  appId: "1:636213952365:web:b64dfd7b9d40a54936e464",
  measurementId: "G-G3XNTJR4BM"
};

const app =initializeApp(firebaseConfig);
const db= getFirestore(app);

export {db};

const Stack = createStackNavigator();

//opretter mine skærme, hvor Home er den første skærm
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Detail" component={DetailScreen} />
        <Stack.Screen name="Create" component={CreateScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
