import React, { useState, useEffect } from 'react';
import { View, Text, Button, FlatList, TouchableOpacity } from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { db } from './App';

// Forskellige aktiviteter der kun er til udseende, der er ingen oplysninger i

const activitiesData = [
  { id: '1', title: 'Unused Hiking Trail' },
  { id: '2', title: 'Unknown City Tour' },
  { id: '3', title: 'Private Beach' },
];

export default function HomeScreen({ navigation }) {
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    // Data fra en database
 const fetchActivites = async () => {
  try {
    const aktivitetShot = await getDocs(collection(db, 'aktiviteter'));
    const aktivitetListe = aktivitetShot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
//jeg kombinerer forrig aktiviteter med aktiviteter fra database
    setActivities([...activitiesData,...aktivitetListe]);
  } catch (error){
    console.error('Fejl ved hentning af data:', error);
  }
 };

 fetchActivites();
},[]);

  //liste af aktiviteter
  return (
    <View style={{ padding: 20 }}>
      <FlatList
        data={activities}
        renderItem={({ item }) => (
          //trykke på aktivitet for at komme til detailScreen
          <TouchableOpacity onPress={() => navigation.navigate('Detail', { activity: item })}>
            <Text style={{ fontSize: 20, marginVertical: 10 }}>{item.title}</Text>
          </TouchableOpacity>
        )}
        keyExtractor={item => item.id}
      />
      <Button title="Create Activity" onPress={() => navigation.navigate('Create')} />
    </View>
  );
}
