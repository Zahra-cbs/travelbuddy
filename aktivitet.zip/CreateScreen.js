import { initializeApp } from "firebase/app"; 
import { db } from "./App";
import { addDoc, collection } from 'firebase/firestore';
import { View, TextInput, Button, StyleSheet, Alert, Image } from 'react-native';
import { getFirestore } from 'firebase/firestore';
import React, {useState} from 'react';

export default function CreateScreen({ navigation })  {
  const [title, setTitle] = useState(''); //titel//
  const [beskrivelse, setBeskrivelse]= useState(''); //beskrivelse
  const [lokation, setLokation] = useState(''); //lokation'
  const [land, setLand] = useState('');//land
  const [budget, setBudget] = useState('');//budget
  const [billede, setBillede] = useState(null);//billede

  //gør det muligt at vælge et billede fra min enhed
  const pickBillede = async ()=> {
    let result = await ImagePicker.launchLibraryAsync({ 
    mediaType: ImagePicker.MediaTypeOptions.Images,
    allowsEdit:true,
    aspect: [4,3],
    quality:1,
  });

  if(!result.canceled){
    setBillede(result.assets[0].uri);
  }
};

  // når jeg trykker på opret aktivitet
  const handleCreate = async () => { 
    if (title.trim() && beskrivelse.trim() && lokation.trim() && land.trim() && budget.trim()) {

        try{
        //tilføjer min nye aktivitet til min database
        await addDoc(collection(db, 'aktiviteter'),{
            title,
            beskrivelse,
            lokation,
            land,
            budget,
            billede,
        });

      // alert når der bliver skrevet noget i tekstfelt
      Alert.alert('Aktivitet Oprettet', `Aktivitet ${title} er blevet oprettet`);
      setTitle('');
      navigation.navigate('Home');  // Naviger tilbage til HomeScreen
    } catch (error) {
        console.error("kunne ikke logge", error)
        //alert, hvis der ikke står noget i tekstfelt
      Alert.alert('Error', 'Kan ikke oprette aktivitet');
    }
  }};

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Activity Title"
        value={title}
        onChangeText={setTitle}
      />

<TextInput
        style={styles.input}
        placeholder="Beskrivelse"
        value={beskrivelse}
        onChangeText={setBeskrivelse}
      />

<TextInput
        style={styles.input}
        placeholder="Lokation"
        value={lokation}
        onChangeText={setLokation}
      />

<TextInput
        style={styles.input}
        placeholder="Land"
        value={land}
        onChangeText={setLand}
      />

<TextInput
        style={styles.input}
        placeholder="Budget"
        value={budget}
        onChangeText={setBudget}
      />


      {billede && (
        <Image source={{uri: billede}} style={styles.billede}/>
      )}

      <Button title="Opret Aktivitet" onPress={handleCreate} />
    </View>
  );
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 20,
      justifyContent: 'center',
    },
    input: {
      borderColor: 'gray',
      borderWidth: 1,
      padding: 10,
      marginBottom: 20,
    },
    image: {
        width: 200,
        height: 200,
        marginVertical: 10,
      },
    });