import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function DetailScreen({ route, navigation }) {
  const { activity } = route.params; // kommer ind til den aktivitet man har trykket på

  //detaljer man ser, når man trykker på en aktivitet
  return (
    <View style={styles.container}>
      <Text style={styles.activityText}>Title: {activity.title}</Text>
      <Text style={styles.activityText}>Description: {activity.beskrivelse}</Text>
      <Text style={styles.activityText}>Location: {activity.lokation}</Text>
      <Text style={styles.activityText}>Country: {activity.land}</Text>
      <Text style={styles.activityText}>Budget: {activity.budget}</Text>
      
      {activity.billede && (
        <Image source={{ uri: activity.billede }} style={styles.image} />
      )}


      <Button title="Go Back" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  activityText: {
    fontSize: 20,
    marginVertical: 10,
  },
  image: {
    width: 200,
    height: 200,
    marginVertical: 10,
  },
});
